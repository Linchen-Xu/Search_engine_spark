package stream

import org.apache.spark.SparkConf
import org.apache.spark.streaming.{Minutes, Seconds, StreamingContext}
import org.apache.spark.streaming.kafka.KafkaUtils

object KafkaStream {
  def main(args: Array[String]): Unit = {
//    if (args.length < 4) {
//      System.err.println("Usage: KafkaWordCount <zkQuorum> <group> <topics> <numThreads>")
//      System.exit(1)
//    }
//    //参数分别为 zk地址，消费者group名，topic名 多个的话，分隔 ，线程数
//    val Array(zkQuorum, group, topics, numThreads) = args


    //spark streaming
    //setmaster，local是调试模式使用
    val sparkConf = new SparkConf().setAppName("KafkaWordCount").setMaster("spark://172.17.11.54:7077")
    val ssc = new StreamingContext(sparkConf, Seconds(10))
    ssc.checkpoint("hdfs://172.17.11.54:9000/checkpoint")

    //kafka
    val topics = "test"   //读取kafka的topic
    val group = "group"     //读取kafka的group
    val zkQuorum = "172.17.11.54:2181,172.17.11.55:2181,172.17.11.56:2181"  //zookeeper地址
    val numThreads = "1"
    //    val brokerList = "10.10.10.196:8092,10.10.10.196:8092"   // broker的地址
    //Map类型存储的是   key： topic名字   values： 读取该topic的消费者的分区数
    val topicMap = topics.split(",").map((_, numThreads.toInt)).toMap

    //参数分别为StreamingContext,kafka的zk地址，消费者group，Map类型
    val kafkamessage = KafkaUtils.createStream(ssc, zkQuorum, group, topicMap)
    //_._2取出kafka的实际消息流
    val lines=kafkamessage.map(_._2)
    lines.print()
    val words = lines.flatMap(_.split(" "))
    val wordCounts = words.map(x => (x, 1L))
      .reduceByKeyAndWindow(_ + _, _ - _, Minutes(1), Seconds(10), 2)
    wordCounts.print()

    ssc.start()
    ssc.awaitTermination()
  }
}
