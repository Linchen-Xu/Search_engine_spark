object WordCount {
  def main(args: Array[String]): Unit = {
    val a = List("python","python","python","python","python","java","java","java","java","java","java")
    val b = a.map(x => (x,1))
    val c = b.groupBy(_._1)
    val d = c.map(x => (x._1,x._2.size))
    d.foreach(println)
  }
}
